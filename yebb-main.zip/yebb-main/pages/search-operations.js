import { Box, Typography } from "@mui/material";

const Page = (props) => {
  return (
    <Box>
      <Typography>Search Operations</Typography>
    </Box>
  );
};

export default Page;
