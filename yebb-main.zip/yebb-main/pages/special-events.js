import { Box, Typography } from "@mui/material"

const Page = (props) => {
    return (
        <Box>
            <Typography>
                Special Events
            </Typography>
        </Box>
    )
}

export default Page