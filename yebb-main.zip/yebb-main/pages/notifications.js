import { Box, Typography } from "@mui/material"

const Page = (props) => {

    return (
        <Box>
            <Typography>
                Notifications
            </Typography>
        </Box>
    )
}

export default Page