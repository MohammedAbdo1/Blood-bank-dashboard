import { Box, Typography } from "@mui/material"

const Page = (props) => {

    return (
        <Box>
            <Typography>
                settings
            </Typography>
        </Box>
    )
}

export default Page