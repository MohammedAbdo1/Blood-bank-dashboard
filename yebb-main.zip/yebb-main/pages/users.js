import { Box, Typography } from "@mui/material"

const Page = (props) => {

    return (
        <Box>
            <Typography>
                Users
            </Typography>
        </Box>
        
    )
}

export default Page