import { Box, Typography } from "@mui/material"

const Page = (props) => {
    return (
        <Box>
            <Typography>
                Reports App
            </Typography>
        </Box>
    )
}

export default Page